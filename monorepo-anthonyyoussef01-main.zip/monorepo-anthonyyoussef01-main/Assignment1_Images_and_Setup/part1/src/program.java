import static java.lang.Math.ceil;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class program {
  // function to remove all occurrences of an element from an array
  public static String[] removeElements(String[] arr, String key)
  {
    // Move all other elements to beginning
    int index = 0;
    for (int i = 0; i < arr.length; i++)
      if (arr[i] != key)
        arr[index++] = arr[i];

    // Create a copy of arr[]
    return Arrays.copyOf(arr, index);
  }

  // creating a deep copy of pixels so that the pixels are not changed as other versions of the
  // image are created.
  public static List<List<List<String>>> pixelsDeepCopy(List<List<List<String>>> pixels) {
    List<List<List<String>>> ret = new ArrayList<List<List<String>>>(pixels.size());
    List<List<String>> retRo = new ArrayList<List<String>>(pixels.size());
    List<String> retPx = new ArrayList<String>(pixels.size());
    for (List<List<String>> ro: pixels) {
      for (List<String> px: ro) {
        for (String cl: px) {
          retPx.add(new String(cl));
        }
        retRo.add(retPx);
        retPx.clear();
      }
      ret.add(retRo);
      retRo.clear();
    }
    return ret;
  }

  // function to darken all the pixels in an A List of Lists of Lists of Strings
  public static List<List<List<String>>> darken(List<List<List<String>>> pixels, int limit) {
    // making a deepcopy of pixels
    List<List<List<String>>> ret = pixelsDeepCopy(pixels);

    int val;
    for (int i = 0; i <= ret.size(); i++) {
      for (int j = 0; j <= ret.get(i).size(); j++) {
        for (int k = 0; k <= ret.get(i).get(j).size(); k++) {
          val = Integer.valueOf(ret.get(i).get(j).get(k)) * 2;
          if (val > limit)
            val = limit;
          ret.get(i).get(j).set(k, String.valueOf(val));
        }
      }
    }
    return ret;
  }

  // function to brighten all the pixels in an A List of Lists of Lists of Strings
  public static List<List<List<String>>> brighten(List<List<List<String>>> pixels) {
    // making a deepcopy of pixels
    List<List<List<String>>> ret = pixelsDeepCopy(pixels);

    int val;
    for (int i = 0; i <= ret.size(); i++) {
      for (int j = 0; j <= ret.get(i).size(); j++) {
        for (int k = 0; k <= ret.get(i).get(j).size(); k++) {
          val = Integer.valueOf(Integer.valueOf(ret.get(i).get(j).get(k)) / 2);
          ret.get(i).get(j).set(k, String.valueOf(val));
        }
      }
    }
    return ret;
  }

  // function to insert pixel in the specified location within pixels
  public static void insertPixel(int x, int y, List<String> pixel,
      List<List<List<String>>> pixels) {
    pixels.get(y).set(x, pixel);
  }

  // function to insert pixels at subsequence points
  public static void drawCircle(int xi, int yi, int x, int y, List<List<List<String>>> pixels) {
    // the list of strings - aka pixel - which will be inserted at the border of the circle
    // (currently assigned to red)
    List<String> red = List.of("255", "0", "0");

    insertPixel(xi+x, yi+y, red, pixels);
    insertPixel(xi-x, yi+y, red, pixels);
    insertPixel(xi+x, yi-y, red, pixels);
    insertPixel(xi-x, yi-y, red, pixels);
    insertPixel(xi+y, yi+x, red, pixels);
    insertPixel(xi-y, yi+x, red, pixels);
    insertPixel(xi+y, yi-x, red, pixels);
    insertPixel(xi-y, yi-x, red, pixels);
  }

  // function for creating the circle using Bresenham's Algorithm
  public static List<List<List<String>>> circleBresenham(int xi, int yi, int r,
      List<List<List<String>>> pixels) {
    // making a deepcopy of pixels
    List<List<List<String>>> ret = pixelsDeepCopy(pixels);

    int x = 0, y = r;
    int d = 3 - 2 * r;
    drawCircle(xi, yi, x, y, ret);

    while (y >= x) {
      // draw all eight pixels for each pixel
      x++;
      // check for decision parameter and correspondingly update d, x, y
      if (d > 0) {
        y--;
        d = d + 4 * (x - y) + 10;
      }
      else
        d = d + 4 * x + 6;

      drawCircle(xi, yi, x, y, ret);
    }
    return ret;
  }

  public static String ppmMaker(List<List<List<String>>> pixels, Double width, Double height,
      Integer maxColorVal, String format, String comments) {
    String ret = "";
    ret += format + "\n";
    ret += comments;

    if (format.equals("P3") || format.equals("p3")) {
      ret += width + " " + height + "\n";
      ret += maxColorVal + "\n";

      ret += pixelsStringFormatter(pixels, maxColorVal.toString());
    }
    else if (format.equals("P6") || format.equals("p6")) {
      ret += Integer.toBinaryString(width.intValue()) + " "
          + Integer.toBinaryString(height.intValue()) + "\n";
      ret += Integer.toBinaryString(maxColorVal) + "\n";

      // making a deepcopy of pixels
      List<List<List<String>>> copyP = pixelsDeepCopy(pixels);

      // converting all the values in ret to binary
      for (int i = 0; i <= copyP.size(); i++) {
        for (int j = 0; j <= copyP.get(i).size(); j++) {
          for (int k = 0; k <= copyP.get(i).get(j).size(); k++) {
            Integer val = Integer.parseInt(copyP.get(i).get(j).get(k));
            copyP.get(i).get(j).set(k, Integer.toBinaryString(val));
          }
        }
      }
      ret += pixelsStringFormatter(copyP, Integer.toBinaryString(maxColorVal));
    }
    else {
      throw new IllegalArgumentException("Encounctered unexpected ppm format.");
    }

    return ret;
  }

  // formats the pixels List of Lists of Lists of Strings to the formatted table with all the pixels
  // arranged well and returns as string to be added onto the end of the file
  private static String pixelsStringFormatter(List<List<List<String>>> pixels, String maxColorVal) {
    int maxLen = maxColorVal.length();

    // organizing the pixels in the string to be returned
    String ret = "";
    int pixLen;
    for (int i = 0; i <= pixels.size(); i++) {
      for (int j = 0; j <= pixels.get(i).size(); j++) {
        for (int k = 0; k <= pixels.get(i).get(j).size(); k++) {
          pixLen = pixels.get(i).get(j).get(k).length();
          if (pixLen < maxLen) {
            if ((maxLen - pixLen) % 2 == 0)
              ret += " ".repeat((maxLen - pixLen) / 2);
            else
              ret += " ".repeat((int)((maxLen - pixLen) / 2));
            ret += pixels.get(i).get(j).get(k) + (int)(ceil((maxLen - pixLen) / 2));
          }
          else
            ret += pixels.get(i).get(j).get(k);
        }
        ret += "  ";
      }
      ret = ret.substring(0, ret.length() - 2);
      if (i != pixels.size())
        ret += "\n";
    }
    return ret;
  }

  public static void exportPixels(String str, String filename) {
    BufferedWriter writer = null;
    try {
      writer = new BufferedWriter(new FileWriter(filename));
      writer.write(str);
    }
    catch (IOException e) {
      e.printStackTrace();
    }
    finally {
      try {
        if (writer != null)
          writer.close( );
      }
      catch (IOException e) {
        e.printStackTrace();
      }
    }
  }

  public static void main(String[] args) {
    // create a file instance from the given filename.
    File inputFile = new File("Assignment1_Images_and_Setup/part1/src/" + args[0]);
    // initialize the variables representing the important information needed from the .ppt file
    String format = null, comments = "";
    Double width = null, height = null;
    Integer maxColorVal = null;
    ArrayList<List<List<String>>> pixels = new ArrayList<List<List<String>>>();
    // initialize the scanner
    Scanner reader = null;
    // Try to open the file whose name was inputted into the command line
    try {
      reader = new Scanner(inputFile);

      // validator?

      // get the format of the ppm image
      if (reader.hasNextLine())
        format = reader.nextLine();

      // extract document information
      while (reader.hasNextLine()) {
        String lineOfText = reader.nextLine();

        // skip the comments
        if (lineOfText.startsWith("#") ) {
          comments += lineOfText + "\n";
          continue;
        }
        else {
          // get dimensions
          String[] seperatedLine = lineOfText.split(" ");
          width = Double.parseDouble(seperatedLine[0]);
          height = Double.parseDouble(seperatedLine[1]);

          // get max color value
          if (reader.hasNextLine()) {
            maxColorVal = Integer.parseInt(reader.nextLine());
          }
          break;
        }
      }

      if (width != null && height != null && maxColorVal != null) {
        ArrayList<String> pixel = new ArrayList<String>();
        ArrayList<List<String>> line = new ArrayList<List<String>>();
        // there will be height number of lines and width number of triples
        int i;
        while (reader.hasNextLine()) {
          String lineOfText = reader.nextLine();
          String[] seperatedLine = lineOfText.split(" ");
          seperatedLine = removeElements(seperatedLine, "");
          List<String> seperatedLineArr = new LinkedList<String>(Arrays.asList(seperatedLine));
          line.clear();
          while(seperatedLineArr.size() >= 3) {
            pixel.clear();
            for(i = 3; i > 0; i--) {
              pixel.add(seperatedLineArr.get(0));
              seperatedLineArr.remove(0);
            }
            line.add(pixel);
          }
          pixels.add(line);
        }
      }
    }
    // Print a Stack race for the error which occurred
    catch (FileNotFoundException e) {
      System.out.println("scanner error");
      e.printStackTrace();
    }
    // Try to close the Buffered Reader
    finally {
      try {
        if (reader != null)
          reader.close();
      } catch (IllegalStateException e) {
        e.printStackTrace();
      }
    }

    // create dark version where the pixels are all half as bright
    List<List<List<String>>> dark = darken(pixels, maxColorVal);
    // create darken_p3.ppm where the pixels are all half as bright
    String darkenP3 = ppmMaker(dark, width, height, maxColorVal, format, comments);
    exportPixels(darkenP3, "darken_p3.ppm");
    // create darken_p6.ppm where the pixels where the pixels are all half as bright
    String darkenP6 = ppmMaker(dark, width, height, maxColorVal, format, comments);
    exportPixels(darkenP6, "darken_p6.ppm");

    // create bright version where the pixels are all twice as bright
    List<List<List<String>>> bright = brighten(pixels);
    // create lighten_p3.ppm where the pixels are all twice as bright
    String brightenP3 = ppmMaker(bright, width, height, maxColorVal, format, comments);
    exportPixels(brightenP3, "lighten_p3");
    // create lighten_p6.ppm where the pixels are all twice as bright
    String brightenP6 = ppmMaker(bright, width, height, maxColorVal, format, comments);
    exportPixels(brightenP6, "lighten_p6.ppm");

    /*
     create a p3 formatted circle.ppm in which a circle is drawn on the image with the following
     requirements:
     1. The background color should be black
     2. The color of the circle can be any color other than black such that I can see it.
     3. The circle can be filled or just an outline.
     4. This means as part of your .ppm library, you will need the ability to modify pixels
        or otherwise create a 'blank' canvas that you can draw on.
    */
    List<List<List<String>>> withCircle = circleBresenham((int)(width/2)-1, (int)(height/2)-1,
        Math.min((int)(width/2)-1, (int)(height/2)-1), pixels);
    String circleP3 = ppmMaker(withCircle, width, height, maxColorVal, format, comments);
    exportPixels(circleP3, "circle.ppm");
  }
}