// Camera Requirement
public class Camera   {
  private Vec3 origin;
  private Vec3 lowerLeftCorner;
  private Vec3 horizontal;
  private Vec3 vertical;
  private double aspect_ratio;
  private double aperture;
  private double focusDist;
  private Vec3 u, w, v;
  private double lensRadius;
  private double t0, t1;          // the shutter open (t0) and close (t1) times

  // constructors
  public Camera() {
    var aspectRatio = 16.0 / 9.0;
    var viewportH = 2.0;
    var viewportW = aspectRatio * viewportH;
    var focalLen = 1.0f;

    this.origin = new Vec3(0, 0, 0);
    this.horizontal = new Vec3(viewportW, 0, 0);
    this.vertical = new Vec3(0, viewportH, 0);
    this.lowerLeftCorner = origin.sub(horizontal.div(2))
        .sub(vertical.div(2))
        .sub(new Vec3(0, 0, focalLen));
    this.t0 = this.t1 = 0;
  }

  public Camera(Vec3 lookFrom, Vec3 lookAt, Vec3 vup, double vfov, double aspectRatio,
      double aperture, double focusDist, double t0, double t1) {
    double theta = Main.degrees_to_radians(vfov);
    double h = Math.tan(theta / 2.0);
    double viewportH = 2.0 * h;
    double viewportW = aspectRatio * viewportH;

    this.w = Vec3.unit_vector(lookFrom.sub(lookAt));
    this.u = Vec3.unit_vector(Vec3.cross(vup, w));
    this.v = Vec3.cross(w, u);

    this.origin = lookFrom;
    this.horizontal = u.mul(focusDist * viewportW);
    this.vertical = v.mul(focusDist * viewportH);
    this.lowerLeftCorner = origin.sub(horizontal.div(2))
        .sub(vertical.div(2))
        .sub(w.mul(focusDist));
    this.lensRadius = aperture / 2.00;
    this.t0 = t0;
    this.t1 = t1;
  }

  public Ray get_ray(double s, double t) {
    Vec3 rd = randomInUnitDisk().mul(lensRadius);
    Vec3 offset = this.u.mul(rd.x()).sub(this.v.mul(rd.y()));

    return new Ray(
        origin.add(offset),
        this.lowerLeftCorner
            .add(this.horizontal.mul(s))
            .add(this.vertical.mul(t))
            .sub(this.origin)
            .sub(offset),
        Main.random_double(this.t0, this.t1)
    );
  }

  // Depth of Field Requirement
  private Vec3 randomInUnitDisk() {
    Vec3 p;
    do {
      p = new Vec3(Main.random_double(-1, 1), Main.random_double(-1, 1), 0);
    } while (p.length_squared() >= 1.0);
    return p;
  }
}