// This class represents a Sphere and is a Hittable
public class Sphere extends Hittable {
  Vec3 center;
  double radius;
  Material mat;

  // constructors
  public Sphere() { }
  public Sphere(Vec3 center, double radius, Material mat){
    this.center = center;
    this.radius = radius;
    this.mat = mat;
  }

  public boolean hit(Ray r, double t_min, double t_max, HitRecord rec){
    Vec3 oc = r.getOrigin().sub(this.center);
    var a = r.getDirection().length_squared();
    var halfB = Vec3.dot(oc, r.getDirection());
    var c = oc.length_squared() - Math.pow(this.radius, 2);

    var discriminant = Math.pow(halfB, 2) - (a * c);
    if (discriminant < 0) {
      return false;
    }

    var sqrtd = Math.sqrt(discriminant);
    var root = (-halfB - sqrtd) / a;
    if (root < t_min || t_max < root) {
      root = (-halfB + sqrtd) / a;
      if (root < t_min || t_max < root)
        return false;
    }

    rec.setT(root);
    rec.setP(r.point_at_parameter(rec.getT()));
    Vec3 outwardNormal = (rec.getP().sub(this.center)).div(this.radius);
    rec.setFaceNormal(r, outwardNormal);
    rec.setMat(this.mat);
    return true;
  }
  /*
  public boolean bounding_box(double t0, double t1, AABB box){
    box.set(new AABB(center.sub(new vec3(radius, radius, radius)),center.add(new vec3(radius, radius, radius))));
    return true;
  }

  public double pdf_value(vec3 o, vec3 v){
    HitRecord rec = new HitRecord();
    if(hit(new Ray(o, v), 0.001, Double.MAX_VALUE, rec)){
      double cos_theta_max = Math.sqrt(1 - radius*radius/(center.sub(o).squared_length()));
      double solid_angle = 2*Math.PI*(1-cos_theta_max);
      return 1/solid_angle; //portion of unit sphere's surface area that is covered by projecting object onto it
    } else {
      return 0;
    }
  }

  public vec3 random(vec3 o){
    //random vector from o to the sphere
    vec3 direction = center.sub(o);
    double distance_squared = direction.squared_length();
    ONB uvw = new ONB();
    uvw.buildFromW(direction);
    return uvw.local(Utilities.random_to_sphere(radius, distance_squared));
  }

  private void get_sphere_uv(vec3 p, HitRecord rec){
    double phi = Math.atan2(p.z(), p.x());
    double theta = Math.asin(p.y());
    rec.u = 1-(phi + Math.PI)/(2*Math.PI);
    rec.v = (theta + Math.PI/2)/Math.PI;
    */
  }