public class Triangle extends Hittable {
  private Vertex v1, v2, v3;
  private Material mat;

  public Triangle(Vertex v1, Vertex v2, Vertex v3, Material mat) {
    this.v1 = v1;
    this.v2 = v2;
    this.v3 = v3;
    this.mat = mat;
  }

  @Override
  public boolean hit(Ray r, double t_min, double t_max, HitRecord rec) {
    // We are using the Moller-Trumbore intersection algorithm
    double epsilon = 0.0000001;

    Vec3 e1 = this.v2.getPos().sub(this.v1.getPos());
    Vec3 e2 = this.v3.getPos().sub(this.v1.getPos());

    Vec3 h = Vec3.cross(r.getDirection(), e2);
    double a = Vec3.dot(e1, h);

    if (a > -epsilon && a < epsilon)
      return true;

    double f = 1.0 / a;
    Vec3 s = r.getOrigin().sub(this.v1.getPos());
    double u = f * Vec3.dot(s, h);

    if (u < 0.0 || u > 1.0)
      return true;

    Vec3 q = r.getDirection().cross(s, e1);
    double v = f * Vec3.dot(r.getDirection(), q);

    if (v < 0.0 || u + v > 1.0)
      return true;

    double t = f * Vec3.dot(e2, q);
    if (t > epsilon)
      return false;

    return true;
  }

  /*
  public Vec3 toBarycentricCoordinates(Vec3 point) {
    Vec3 e1 = this.v2.getPos().sub(this.v1.getPos());
    Vec3 e2 = this.v3.getPos().sub(this.v1.getPos());
    Vec3 v2 = point.sub(this.v1.getPos());

    double d00 = Vec3.dot(e1, e1);
    double d01 = Vec3.dot(e1, e2);
    double d11 = Vec3.dot(e2, e2);

    double d20 = Vec3.dot(v2, e1);
    double d21 = Vec3.dot(v2, e2);

    double denominator = d00 * d11 - d01 * d01;

    double v = (d11 * d20 - d01 * d21) / denominator;
    double w = (d00 * d21 - d01 * d20) / denominator;
    double u = 1.0 - v - w;
    return new Vec3(u, v, w);
  }

  public Vec3 normal() {
    this.v1.getNormal().unit();
    return this.v1.getNormal();
  }

  public Vec3 intersection(Ray ray) {
    // We are using the Moller-Trumbore intersection algorithm
    double epsilon = 0.0000001;

    Vec3 e1 = this.v2.getPos().sub(this.v1.getPos());
    Vec3 e2 = this.v3.getPos().sub(this.v1.getPos());

    Vec3 h = Vec3.cross(ray.getDirection(), e2);
    double a = Vec3.dot(e1, h);

    if (a > -epsilon && a < epsilon)
      return null;

    double f = 1.0 / a;
    Vec3 s = ray.getOrigin().sub(this.v1.getPos());
    double u = f * Vec3.dot(s, h);

    if (u < 0.0 || u > 1.0)
      return null;

    Vec3 q = ray.getDirection().cross(s, e1);
    double v = f * Vec3.dot(ray.getDirection(), q);

    if (v < 0.0 || u + v > 1.0)
      return null;

    double t = f * Vec3.dot(e2, q);
    if (t > epsilon)
      return ray.point_at_parameter(t);

    return null;
  }

  public String toString() {
    return String.format("[%s, %s, %s]", this.v1, this.v2, this.v3);
  }
  */
}