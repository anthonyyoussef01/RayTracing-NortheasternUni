// Motion Blur Requirement:
// a class that represents a similar version of the Sphere class which is a Hittable
// but with motion blur.
public class MovingSphere extends Hittable {
  private Vec3 cen0, cen1;
  private double t0, t1;
  private double radius;
  private Material mat;

  // constructors
  public MovingSphere() { }
  public MovingSphere(Vec3 cen0, Vec3 cen1, double t0, double t1, double radius, Material mat) {
    this.cen0 = cen0;
    this.cen1 = cen1;
    this.t0 = t0;
    this.t1 = t1;
    this.radius = radius;
    this.mat = mat;
  }

  public boolean hit(Ray r, double t_min, double t_max, HitRecord rec) {
    Vec3 oc = r.getOrigin().sub(this.center(r.getTime()));
    var a = r.getDirection().length_squared();
    var halfB = Vec3.dot(oc, r.getDirection());
    var c = oc.length_squared() - Math.pow(this.radius, 2);

    var discriminant = Math.pow(halfB, 2) - (a * c);
    if (discriminant < 0) {
      return false;
    }

    var sqrtd = Math.sqrt(discriminant);
    var root = (-halfB - sqrtd) / a;
    if (root < t_min || t_max < root) {
      root = (-halfB + sqrtd) / a;
      if (root < t_min || t_max < root)
        return false;
    }

    rec.setT(root);
    rec.setP(r.point_at_parameter(rec.getT()));
    Vec3 outwardNormal = (rec.getP().sub(this.center(r.getTime()))).div(this.radius);
    rec.setFaceNormal(r, outwardNormal);
    rec.setMat(this.mat);
    return true;
  }

  public Vec3 center(double time) {
    return this.cen0.add(
        (this.cen1.sub(this.cen0))
            .mul((time - this.t0) / (this.t1 - this.t0))
    );
  };
}