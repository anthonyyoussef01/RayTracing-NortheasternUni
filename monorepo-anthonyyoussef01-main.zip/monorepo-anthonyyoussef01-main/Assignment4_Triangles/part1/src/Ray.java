public class Ray {
  private Vec3 origin;
  private Vec3 direction;
  private double time = 0.00;

  // constructors
  public Ray(){ }
  public Ray(Vec3 origin, Vec3 direction){
    this.origin = origin;
    this.direction = direction;
  }
  public Ray(Vec3 origin, Vec3 direction, double time) {
    this.origin = origin;
    this.direction = direction;
    this.time = time;
  }

  // getters
  public Vec3 getOrigin() {return origin; }
  public Vec3 getDirection() { return direction; }
  public double getTime() { return time; }

  // setters
  public void set(Ray r){
    this.origin = r.origin;
    this.direction = r.direction;
  }
  public void setOrigin(Vec3 origin) {
    this.origin = origin;
  }
  public void setDirection(Vec3 direction) {
    this.direction = direction;
  }

  // utilize the function P(t)=A+tb to find the position on the ray
  public Vec3 point_at_parameter(double t) {
    return origin.add(direction.mul(t));
  }
}