public class Vec3 {
  private double[] e = new double[3];

  // constructors
  public Vec3(double e0, double e1, double e2) {
    e[0] = e0;
    e[1] = e1;
    e[2] = e2;
  }
  public Vec3() {
    e[0] = 0;
    e[1] = 0;
    e[2] = 0;
  }
  public Vec3(double e) {
    this(e,e,e);
  }

  // getters
  public double x() { return e[0]; }
  public double y() { return e[1]; }
  public double z() { return e[2]; }

  // setters
  public double r() { return e[0]; }
  public double g() { return e[1]; }
  public double b() { return e[2]; }

  // override vec3 class addition
  public Vec3 add(Vec3 v) {
    return new Vec3(
        e[0] + v.e[0],
        e[1] + v.e[1],
        e[2] + v.e[2]
    );
  }

  // override vec3 class subtraction
  public Vec3 sub(Vec3 v) {
    return new Vec3(
        e[0] - v.e[0],
        e[1] - v.e[1],
        e[2] - v.e[2]
    );
  }

  // override vec3 class division by another vec3
  public Vec3 div(Vec3 v) {
    return new Vec3(
        e[0] / v.e[0],
        e[1] / v.e[1],
        e[2] / v.e[2]
    );
  }

  // override vec3 class division by a double
  public Vec3 div(double t) {
    return new Vec3(
        e[0] / t,
        e[1] / t,
        e[2] / t
    );
  }

  // override vec3 class multiplication by a vec3
  public Vec3 mul(Vec3 v) {
    return new Vec3(
        e[0] * v.e[0],
        e[1] * v.e[1],
        e[2] * v.e[2]
    );
  }

  // override vec3 class multiplication by a double
  public Vec3 mul(double t) {
    return new Vec3(
        e[0] * t,
        e[1] * t,
        e[2] * t
    );
  }

  // vec3 class dot product
  public static double dot(Vec3 v1, Vec3 v2) {
    return
        v1.e[0] * v2.e[0] +
        v1.e[1] * v2.e[1] +
        v1.e[2] * v2.e[2];
  }

  // vec3 class cross product
  public static Vec3 cross(Vec3 v1, Vec3 v2) {
    return new Vec3(
        (v1.e[1]*v2.e[2] - v1.e[2]*v2.e[1]),
        -(v1.e[0]*v2.e[2] - v1.e[2]*v2.e[0]),
        (v1.e[0]*v2.e[1] - v1.e[1]*v2.e[0])
    );
  }

  // Additional vec3 utility functions which divides v by its length
  public static Vec3 unit_vector(Vec3 v) {
    return v.div(v.length());
  }

  // Additional vec3 utility functions which sets each element of this vec3 to 1.0 divided by itself
  public void unit() {
    double k = 1.0 / length();
    e[0] *= k;
    e[1] *= k;
    e[2] *= k;
  }

  // override vec3 class setter
  public void set(Vec3 v) {
    e[0] = v.e[0];
    e[1] = v.e[1];
    e[2] = v.e[2];
  }

  // override vec3 class getter
  public double get(int i) {
    return e[i];
  }

  // override vec3 class printing
  public String toString() {
    return "<" + e[0] + ", " + e[1] + ", " + e[2] + ">";
  }

  // override vec3 class equality
  public boolean equals(Vec3 v) {
    return
        e[0] == v.e[0] &&
        e[1] == v.e[1] &&
        e[2] == v.e[2];
  }

  // returns the length of vec3 using the pythagorean theorem
  public double length() {
    return Math.sqrt(this.length_squared());
  }

  // returns the square of the length of vec3
  public double length_squared() {
    return Math.pow(e[0], 2) + Math.pow(e[1], 2) + Math.pow(e[2], 2);
  }

  // returns the negations of this vec3
  public Vec3 neg() {
    return new Vec3(-e[0], -e[1], -e[2]);
  }

  // pick a random point in the unit cube where x, y, and z all range from −1 to +1
  public static Vec3 random() {
    return new Vec3(Main.random_double(), Main.random_double(), Main.random_double());
  }
  public static Vec3 random(double min, double max) {
    return new Vec3(
        Main.random_double(min,max),
        Main.random_double(min,max),
        Main.random_double(min,max)
    );
  }
  public static Vec3 randomInUnitSphere() {
    while (true) {
      Vec3 p = random(-1, 1);
      if (p.length_squared() >= 1)
        continue;
      return p;
    }
  }
  public static Vec3 randomUnitVector() {
    return unit_vector(randomInUnitSphere());
  }
  public static Vec3 random_in_hemisphere(final Vec3 normal) {
    Vec3 inUnitSphere = randomInUnitSphere();
    if (dot(inUnitSphere, normal) > 0.0) {
      return inUnitSphere;
    } else {
      return inUnitSphere.neg();
    }
  }

  // returns true if the vector is very close to zero in all dimensions
  public boolean near_zero() {
    var s = 1e-8;
    return (Math.abs(e[0]) < s) && (Math.abs(e[1]) < s) && (Math.abs(e[2]) < s);
  }

  // Reflection Requirement:
  // utilize v+2b to calculate the ray reflected off of an object
  public static Vec3 reflect(final Vec3 v, final Vec3 n) {
    return v.sub(
        n.mul(2).mul(dot(v, n))
    );
  }
}