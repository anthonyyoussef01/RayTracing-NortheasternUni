public class Metal extends Material {
  public Vec3 albedo;

  public Metal(Vec3 albedo) {
    this.albedo = albedo;
  }

  @Override
  public boolean scatter(Ray rIn, HitRecord rec, Vec3 attenuation, Ray scattered) {
    Vec3 reflected = Vec3.reflect(Vec3.unit_vector(rIn.getDirection()), rec.getNormal());
    scattered.set(new Ray(rec.getP(), reflected, rIn.getTime()));
    attenuation.set(albedo);
    return Vec3.dot(scattered.getDirection(), rec.getNormal()) > 0;
  }
}