// a Material abstract class that represents any material for objects such as Metal or Glass
public abstract class Material {
  public abstract boolean scatter(
      final Ray rIn,
      final HitRecord rec,
      Vec3 attenuation,
      Ray scattered
  );
}