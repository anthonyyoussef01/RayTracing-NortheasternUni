import java.io.*;
import java.util.*;

/*
  OBJ Requirement
  Class to parse the .obj files to be used
*/
public class ObjParser {
  public static Vec3 parseVertex(String[] data) {
    return new Vec3(Double.parseDouble(data[1]), Double.parseDouble(data[2]), Double.parseDouble(data[3]));
  }

  public static Vec3 parseNormal(String[] data) {
    return new Vec3(Double.parseDouble(data[1]), Double.parseDouble(data[2]), Double.parseDouble(data[3]));
  }

  public static Vertex parseTriangleVertex(String[] data, List<Vec3> vertices,
      List<Vec3> textureCoordinates, List<Vec3> normals) {
    Vec3 vertex = null;
    if (! data[0].isEmpty()) {
      int vertexIndex = Integer.parseInt(data[0]) - 1;
      vertex = vertices.get(vertexIndex);
    }

    Vec3 textureCoordinate = null;
    if (!data[1].isEmpty()) {
      int textureCoordinateIndex = Integer.parseInt(data[1]) - 1;
      textureCoordinate = textureCoordinates.get(textureCoordinateIndex);
    }

    Vec3 normal = null;
    if (!data[2].isEmpty()) {
      int normalIndex = Integer.parseInt(data[2]) - 1;
      normal = normals.get(normalIndex);
    }

    return new Vertex(vertex, textureCoordinate, normal);
  }

  public static Triangle parseFace(String[] data, ArrayList<Vec3> vertices,
      List<Vec3> textureCoordinates, List<Vec3> normals, Material mat) {
    return new Triangle(
        parseTriangleVertex(data[1].split("/"), vertices, textureCoordinates, normals),
        parseTriangleVertex(data[2].split("/"), vertices, textureCoordinates, normals),
        parseTriangleVertex(data[3].split("/"), vertices, textureCoordinates, normals),
        mat
    );
  }

  public static Triangle[] parseFile(File file, Material mat) throws Exception {
    BufferedReader input = new BufferedReader(new FileReader(file));

    ArrayList<Vec3> vertices = new ArrayList<>();
    ArrayList<Vec3> textureCoordinates = new ArrayList<>();
    ArrayList<Vec3> normals = new ArrayList<>();
    ArrayList<Triangle> faces = new ArrayList<>();

    String line;
    while ((line = input.readLine()) != null) {
      String[] data = line.split(" ");
      // line encoding
      switch (data[0]) {
        case "v":
          vertices.add(parseVertex(data));
          break;
        case "vn":
          normals.add(parseNormal(data));
          break;
        case "f":
          faces.add(parseFace(data, vertices, textureCoordinates, normals, mat));
          break;
      }
    }
    input.close();

    Triangle[] facesArray = new Triangle[faces.size()];
    facesArray = faces.toArray(facesArray);
    return facesArray;
  }
}