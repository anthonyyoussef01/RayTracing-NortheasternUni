import java.util.ArrayList;
import java.util.List;

public class HittableList extends Hittable {
  private List<Hittable> hittableList;

  // constructors
  HittableList() {
    this.hittableList = new ArrayList<>();
  }
  HittableList(List<Hittable> hittableList) {
    this.hittableList = hittableList;
  }
  HittableList(Hittable hittableObj) {
    this.hittableList = new ArrayList<>();
    this.hittableList.add(hittableObj);
  }

  public void clear() {
    this.hittableList.clear();
  }

  public void add(Hittable obj) {
      this.hittableList.add(obj);
  }

  public boolean hit(Ray ray, double tMin, double tMax, HitRecord hitRecord) {
    HitRecord tempHitRecord = new HitRecord();
    boolean hitAnything = false;
    var closestSoFar = tMax;

    for (Hittable hitbl : hittableList)
      if (hitbl.hit(ray, tMin, closestSoFar, tempHitRecord)) {
        hitAnything = true;
        closestSoFar = tempHitRecord.getT();
        hitRecord.set(tempHitRecord);
      }
    return hitAnything;
  }
}