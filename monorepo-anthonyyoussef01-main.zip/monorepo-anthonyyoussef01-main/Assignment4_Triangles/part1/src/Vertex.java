public class Vertex {

  private Vec3 pos;
  public Vec3 textureCoordinate;
  private Vec3 normal;

  public Vec3 getPos() {
    return this.pos;
  }
  public Vec3 getNormal() {
    return this.pos;
  }

  public void setPos(Vec3 pos) {
    this.pos = pos;
  }

  public Vertex(Vec3 pos, Vec3 textureCoordinate, Vec3 normal) {
    this.pos = pos;
    this.textureCoordinate = textureCoordinate;
    this.normal = normal;
  }

  public String toString() {
    return String.format("<%s, %s, %s>", this.pos, this.textureCoordinate, this.normal);
  }

}