# Run.md

In order to run this script and update the output.ppm,
one would need to run Main.java as shown below:

    javac Main.java
    java Main