import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class main {
  public static double clamp(double x, double min, double max) {
    if (x < min)
      return min;
    if (x > max)
      return max;
    return x;
  }

  public static void write_color(Writer out, vec3 pixel_color, int samplesPerPixel)
      throws IOException {
    var r = pixel_color.x();
    var g = pixel_color.y();
    var b = pixel_color.z();

    // Gamma Requirement:
    // Divide the color by the number of samples
    // and gamma-correct for gamma=2.0.
    var scale = 1.0 / samplesPerPixel;
    r = sqrt(scale * r);
    g = sqrt(scale * g);
    b = sqrt(scale * b);

    // Write the translated [0,255] value of each color component.
    out.append(
        (int)(256 * clamp(r, 0.0, 0.999)) + " " +
        (int)(256 * clamp(g, 0.0, 0.999)) + " " +
        (int)(256 * clamp(b, 0.0, 0.999)) + "\n");
  }

  public static vec3 ray_color(ray r, hittable world, int depth) {
    HitRecord rec = new HitRecord();

    // ray bounce limit exceeded -> no more light is gathered
    if (depth <= 0)
      return new vec3(0, 0, 0);

    if (world.hit(r, 0.001, Double.POSITIVE_INFINITY, rec)) {
      ray scattered = new ray();
      vec3 attenuation = new vec3();
      if (rec.getMat().scatter(r, rec, attenuation, scattered))
        return attenuation.mul(ray_color(scattered, world, depth-1));
      return new vec3(0, 0, 0);
    }

    vec3 unit_direction = vec3.unit_vector(r.getDirection());
    var t = 0.5f * (float)(unit_direction.y() + 1.0);
    /*
    return new vec3(
        (1.0f - t) * 1.0f + t * 0.5f,
        (1.0f - t) * 1.0f + t * 0.7f,
        (1.0f - t) * 1.0f + t * 1.0f
    );
    */
    return (new vec3(1.0, 1.0, 1.0).mul(1.0f - t)).add(new vec3(0.5, 0.7, 1.0).mul(t));
  }

  // returns the degrees value entered in radians
  public static double degrees_to_radians(double degrees) {
    return degrees * Math.PI / 180.0;
  }

  public static double random_double() {
    // The Java Math library function Math.random() generates a double value in the range [0,1)
    return Math.random();
  }

  public static double random_double(double min, double max) {
    // Returns a random real in [min,max)
    var range = max - min + 1;
    return (Math.random() * range) + min;
  }

  public static void main(String[] args) {
    // PPM Requirement:
    // try opening file first and print stack trace if error encountered
    BufferedWriter writer = null;
    try
    {
      writer =
          new BufferedWriter(
              new FileWriter(
                  "Assignment2_FirstRayTracer/part1/src/output.ppm"
              )
          );
      // initialize width and height of the canvas
      var aspectRatio = 16.0 / 9.0;
      int width = 400;
      int height = (int)(width / aspectRatio);
      int samplesPerPixel = 100;
      int maxDepth = 50;

      // initialize the world
      HittableList world = new HittableList();
      var material_ground = new Lambertian(new vec3(0.1, 0.5, 1.0));
      var material_center = new Lambertian(new vec3(0.5, 0.2, 0.6));
      var material_left   = new Metal(new vec3(0.1, 0.1, 0.1));
      var material_right  = new Metal(new vec3(0.7, 1.0, 0.9));
      // Sphere Requirement (4 Spheres: 1 of them is ground) &
      // Materials Requirement (Lambertian & Metal) :
      world.add(new Sphere(new vec3(0.0, -100.5, -1.0), 100.0, material_ground));
      world.add(new Sphere(new vec3(0.0,    0.3, -1.3),   0.3, material_center));
      world.add(new Sphere(new vec3(-1.1,   0.4, -1.2),   1.0, material_left));
      world.add(new Sphere(new vec3( 1.1,   0.1, -1.1),   0.6, material_right));

      // create a Camera instance
      Camera cam = new Camera();

      // write file
      writer.write("P3\n" + width + " " + height + "\n255\n");
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " ");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          vec3 pixelColor = new vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world, maxDepth));
          }
          write_color(writer, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone\r");
    } catch (IOException e) {
      e.printStackTrace();
    }
    // try closing file
    finally {
      try {
        if (writer != null)
          writer.close( );
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
