import java.util.ArrayList;
import java.util.List;

public class HittableList extends hittable {
  private List<hittable> hittableList;

  // constructors
  HittableList() {
    this.hittableList = new ArrayList<>();
  }
  HittableList(List<hittable> hittableList) {
    this.hittableList = hittableList;
  }
  HittableList(hittable hittableObj) {
    this.hittableList = new ArrayList<>();
    this.hittableList.add(hittableObj);
  }

  public void clear() {
    this.hittableList.clear();
  }

  public void add(hittable obj) {
      this.hittableList.add(obj);
  }

  public boolean hit(ray ray, double tMin, double tMax, HitRecord hitRecord) {
    HitRecord tempHitRecord = new HitRecord();
    boolean hitAnything = false;
    var closestSoFar = tMax;

    for (hittable hitbl : hittableList)
      if (hitbl.hit(ray, tMin, closestSoFar, tempHitRecord)) {
        hitAnything = true;
        closestSoFar = tempHitRecord.getT();
        hitRecord.set(tempHitRecord);
      }
    return hitAnything;
  }
}