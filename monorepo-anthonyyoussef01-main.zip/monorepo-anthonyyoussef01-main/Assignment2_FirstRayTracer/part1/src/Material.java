// a Material abstract class that represents any material for objects such as Metal or Glass
public abstract class Material {
  public abstract boolean scatter(
      final ray rIn,
      final HitRecord rec,
      vec3 attenuation,
      ray scattered
  );
}