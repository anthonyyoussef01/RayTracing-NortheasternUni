public class ray{
  private vec3 origin;
  private vec3 direction;

  // constructors
  public ray(){ }
  public ray(vec3 origin, vec3 b){
    this.origin = origin;
    this.direction = b;
  }
  public ray(vec3 origin, vec3 b, double time) {
    this.origin = origin;
    this.direction = b;
  }

  // getters
  public vec3 getOrigin() {return origin; }
  public vec3 getDirection() { return direction; }

  // setters
  public void set(ray r){
    this.origin = r.origin;
    this.direction = r.direction;
  }
  public void setOrigin(vec3 origin) {
    this.origin = origin;
  }
  public void setDirection(vec3 direction) {
    this.direction = direction;
  }

  // utilize the function P(t)=A+tb to find the position on the ray
  public vec3 point_at_parameter(double t) {
    return origin.add(direction.mul(t));
  }
}