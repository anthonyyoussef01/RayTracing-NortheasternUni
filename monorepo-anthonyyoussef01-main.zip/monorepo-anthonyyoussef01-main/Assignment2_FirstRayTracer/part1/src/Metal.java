public class Metal extends Material {
  public vec3 albedo;

  public Metal(vec3 albedo) {
    this.albedo = albedo;
  }

  @Override
  public boolean scatter(ray rIn, HitRecord rec, vec3 attenuation, ray scattered) {
    vec3 reflected = vec3.reflect(vec3.unit_vector(rIn.getDirection()), rec.getNormal());
    scattered.set(new ray(rec.getP(), reflected));
    attenuation.set(albedo);
    return vec3.dot(scattered.getDirection(), rec.getNormal()) > 0;
  }
}