public class HitRecord {
  private vec3 p;
  private vec3 normal;
  private Material mat;
  private double t;
  private boolean  front_face;
  //Hittable h;
  //private double u, v;

  // constructor
  public HitRecord() {
    this.p = new vec3();
    this.t = 0;
    this.normal = new vec3();
  }
  public HitRecord(vec3 p, vec3 normal, double t, Material mat) {
    this.p = p;
    this.normal = normal;
    this.t = t;
    this.mat = mat;
    //this.mat = mat;
    //this.h = h;
    //this.u = u;
    //this.v = v;
  }

  // setters
  public void set(HitRecord hr){
    this.p.set(hr.p);
    this.normal.set(hr.normal);
    this.t = hr.t;
    this.front_face = hr.front_face;
    this.mat = hr.mat;
    //this.h = hr.h;
    //this.u = hr.u;
    //this.v = hr.v;
  }
  public void setT(double t){
    this.t = t;
  }
  public void setP(vec3 p) {
    this.p = p;
  }
  public void setNormal(vec3 normal) {
    this.normal = normal;
  }
  public void setMat(Material mat) {
    this.mat = mat;
  }

  public void setFaceNormal(ray r, vec3 outwardNormal) {
    front_face = vec3.dot(r.getDirection(), outwardNormal) < 0;
    normal = front_face ? outwardNormal : outwardNormal.neg();
  }

  // getters
  public vec3 getP() {
    return this.p;
  }
  public vec3 getNormal() {
    return this.normal;
  }
  public double getT() {
    return this.t;
  }
  public Material getMat() {
    return this.mat;
  }
}