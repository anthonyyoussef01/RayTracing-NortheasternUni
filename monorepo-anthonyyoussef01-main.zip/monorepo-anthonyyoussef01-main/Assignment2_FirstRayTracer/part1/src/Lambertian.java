public class Lambertian extends Material {
  public vec3 albedo;

  // constuctors
  public Lambertian(final vec3 albedo) {
    this.albedo = albedo;
  }
  /*
  public Lambertian(double e1, double e2, double e3) {
    this.albedo = new vec3(e1, e2, e3);
  }
  */

  @Override
  public boolean scatter(ray rIn, HitRecord rec, vec3 attenuation, ray scattered) {
    var scatter_direction = rec.getNormal().add(vec3.randomUnitVector());

    // Catch degenerate scatter direction
    if (scatter_direction.near_zero()) {
      scatter_direction = rec.getNormal();
    }

    scattered.set(new ray(rec.getP(), scatter_direction));
    attenuation.set(albedo);
    return true;
  }
}