import java.io.IOException;
import java.io.Writer;

// Camera Requirement
public class Camera {
  private vec3 origin;
  private vec3 lowerLeftCorner;
  private vec3 horizontal;
  private vec3 vertical;

  // constructors
  public Camera() {
    var aspectRatio = 16.0 / 9.0;
    var viewportH = 2.0;
    var viewportW = aspectRatio * viewportH;
    var focalLen = 1.0f;

    this.origin = new vec3(0, 0, 0);
    this.horizontal = new vec3(viewportW, 0, 0);
    this.vertical = new vec3(0, viewportH, 0);
    this.lowerLeftCorner = origin.sub(horizontal.div(2))
        .sub(vertical.div(2))
        .sub(new vec3(0, 0, focalLen));
  }
  /*
  public Camera(vec3 lookFrom, vec3 lookAt, vec3 vup, double vfov, double aspect_ratio, double aperture, double focus_dist) {
    double theta = Utils.degreeToRadian(vfov);
    double h = Math.tan(theta / 2.0);
    double viewport_height = 2.0 * h;
    double viewport_width = aspect_ratio * viewport_height;

    w = lookFrom.Sub(lookAt).normalize();
    u = vup.Cross(w).normalize();
    v = w.Cross(u);

    origin = lookFrom;
    horizontal = u.Scale(focus_dist * viewport_width);
    vertical = v.Scale(focus_dist * viewport_height);
    lower_left_corner = origin.Sub(horizontal.Div(2)).Sub(vertical.Div(2)).Sub(w.Scale(focus_dist));
    lens_radius = aperture / 2;
  }
  */

  public ray get_ray(double u, double v) {
    vec3 point3 =
        this.lowerLeftCorner
        .add(this.horizontal.mul(u))
        .add(this.vertical.mul(v))
        .sub(this.origin);
    return new ray(this.origin, point3);
  }
}