# Windows

* WSL
  * Windows users have reportedly been able to use WSL to some degree of success.
  * Some students have used WSL plus XMing (and exporting display) to execute graphical applications
* WSL 2
  * The new WSL2 may also be an option as long as it can run the needed graphics libraries.
