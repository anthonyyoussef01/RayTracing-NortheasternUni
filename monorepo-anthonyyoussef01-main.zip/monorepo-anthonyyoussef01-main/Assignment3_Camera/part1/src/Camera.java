import java.io.IOException;
import java.io.Writer;

// Camera Requirement
public class Camera   {
  private vec3 origin;
  private vec3 lowerLeftCorner;
  private vec3 horizontal;
  private vec3 vertical;
  private double aspect_ratio;
  private double aperture;
  private double focusDist;
  private vec3 u, w, v;
  private double lensRadius;

  // constructors
  public Camera() {
    var aspectRatio = 16.0 / 9.0;
    var viewportH = 2.0;
    var viewportW = aspectRatio * viewportH;
    var focalLen = 1.0f;

    this.origin = new vec3(0, 0, 0);
    this.horizontal = new vec3(viewportW, 0, 0);
    this.vertical = new vec3(0, viewportH, 0);
    this.lowerLeftCorner = origin.sub(horizontal.div(2))
        .sub(vertical.div(2))
        .sub(new vec3(0, 0, focalLen));
  }

  public Camera(vec3 lookFrom, vec3 lookAt, vec3 vup, double vfov, double aspectRatio,
      double aperture, double focusDist) {
    double theta = main.degrees_to_radians(vfov);
    double h = Math.tan(theta / 2.0);
    double viewportH = 2.0 * h;
    double viewportW = aspectRatio * viewportH;

    this.w = vec3.unit_vector(lookFrom.sub(lookAt));
    this.u = vec3.unit_vector(vec3.cross(vup, w));
    this.v = vec3.cross(w, u);

    this.origin = lookFrom;
    this.horizontal = u.mul(focusDist * viewportW);
    this.vertical = v.mul(focusDist * viewportH);
    this.lowerLeftCorner = origin.sub(horizontal.div(2))
        .sub(vertical.div(2))
        .sub(w.mul(focusDist));
    this.lensRadius = aperture / 2.00;
  }

  public ray get_ray(double s, double t) {
    vec3 rd = randomInUnitDisk().mul(lensRadius);
    vec3 offset = this.u.mul(rd.x()).sub(this.v.mul(rd.y()));

    return new ray(
        origin.add(offset),
        this.lowerLeftCorner
            .add(this.horizontal.mul(s))
            .add(this.vertical.mul(t))
            .sub(this.origin)
            .sub(offset)
    );
  }

  // Depth of Field Requirement
  private vec3 randomInUnitDisk() {
    vec3 p;
    do {
      p = new vec3(main.random_double(-1, 1), main.random_double(-1, 1), 0);
    } while (p.length_squared() >= 1.0);
    return p;
  }
}