import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class main {
  public static double clamp(double x, double min, double max) {
    if (x < min)
      return min;
    if (x > max)
      return max;
    return x;
  }

  public static void write_color(Writer out, vec3 pixel_color, int samplesPerPixel)
      throws IOException {
    var r = pixel_color.x();
    var g = pixel_color.y();
    var b = pixel_color.z();

    // Gamma Requirement:
    // Divide the color by the number of samples
    // and gamma-correct for gamma=2.0.
    var scale = 1.0 / samplesPerPixel;
    r = sqrt(scale * r);
    g = sqrt(scale * g);
    b = sqrt(scale * b);

    // Write the translated [0,255] value of each color component.
    out.append(
        (int)(256 * clamp(r, 0.0, 0.999)) + " " +
        (int)(256 * clamp(g, 0.0, 0.999)) + " " +
        (int)(256 * clamp(b, 0.0, 0.999)) + "\n");
  }

  public static vec3 ray_color(ray r, hittable world, int depth) {
    HitRecord rec = new HitRecord();

    // ray bounce limit exceeded -> no more light is gathered
    if (depth <= 0)
      return new vec3(0, 0, 0);

    if (world.hit(r, 0.001, Double.POSITIVE_INFINITY, rec)) {
      ray scattered = new ray();
      vec3 attenuation = new vec3();
      if (rec.getMat().scatter(r, rec, attenuation, scattered))
        return attenuation.mul(ray_color(scattered, world, depth-1));
      return new vec3(0, 0, 0);
    }

    vec3 unit_direction = vec3.unit_vector(r.getDirection());
    var t = 0.5f * (float)(unit_direction.y() + 1.0);
    /*
    return new vec3(
        (1.0f - t) * 1.0f + t * 0.5f,
        (1.0f - t) * 1.0f + t * 0.7f,
        (1.0f - t) * 1.0f + t * 1.0f
    );
    */
    return (new vec3(1.0, 1.0, 1.0).mul(1.0f - t)).add(new vec3(0.5, 0.7, 1.0).mul(t));
  }

  // returns the degrees value entered in radians
  public static double degrees_to_radians(double degrees) {
    return degrees * Math.PI / 180.0;
  }

  // Antialiasing Requirement:
  public static double random_double() {
    // The Java Math library function Math.random() generates a double value in the range [0,1)
    return Math.random();
  }

  public static double random_double(double min, double max) {
    // Returns a random real in [min,max)
    var range = max - min + 1;
    return (Math.random() * range) + min;
  }

  public static void main(String[] args) {
    // PPM Requirement:
    // try opening file first and print stack trace if error encountered
    BufferedWriter writer1 = null;
    BufferedWriter writer2 = null;
    BufferedWriter writer3 = null;
    BufferedWriter writer4 = null;
    BufferedWriter writer5 = null;
    try
    {
      writer1 =
          new BufferedWriter(
              new FileWriter(
                  "Assignment3_Camera/part1/src/output1.ppm"
              )
          );
      writer2 =
          new BufferedWriter(
              new FileWriter(
                  "Assignment3_Camera/part1/src/output2.ppm"
              )
          );
      writer3 =
          new BufferedWriter(
              new FileWriter(
                  "Assignment3_Camera/part1/src/output3.ppm"
              )
          );
      writer4 =
          new BufferedWriter(
              new FileWriter(
                  "Assignment3_Camera/part1/src/output4.ppm"
              )
          );
      writer5 =
          new BufferedWriter(
              new FileWriter(
                  "Assignment3_Camera/part1/src/output5.ppm"
              )
          );
      // initialize width and height of the canvas
      var aspectRatio = 16.0 / 9.0;
      int width = 400;
      int height = (int)(width / aspectRatio);
      int samplesPerPixel = 100;
      int maxDepth = 50;

      // initialize the world
      HittableList world = new HittableList();
      var material_ground = new Lambertian(new vec3(0.1, 0.5, 1.0));
      var material_center = new Lambertian(new vec3(0.5, 0.2, 0.6));
      var material_left   = new Metal(new vec3(0.1, 0.1, 0.1));
      var material_right  = new Metal(new vec3(0.7, 1.0, 0.9));
      // Sphere Requirement (4 Spheres: 1 of them is ground) &
      // Materials Requirement (Lambertian & Metal) :
      world.add(new Sphere(new vec3(0.0, -100.5, -1.0), 100.0, material_ground));
      world.add(new Sphere(new vec3(0.0,    0.2, -1.3),   0.3, material_center));
      world.add(new Sphere(new vec3(-1.1,   0.2, -1.2),   1.0, material_left));
      world.add(new Sphere(new vec3( 1.1,   0.1, -1.1),   0.6, material_right));

      // create a Camera instance
      vec3 lookfrom = new vec3(2,3,2);
      vec3 lookat = new vec3(0,0,-1);
      vec3 vup = new vec3(0,1,0);
      var distToFocus = (lookfrom.sub(lookat)).length();
      var aperture = 2.0;

      Camera cam= new Camera(lookfrom, lookat, vup, 20.0, aspectRatio, aperture, distToFocus);

      // write file 1
      writer1.write("P3\n" + width + " " + height + "\n255\n");
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " for file 1");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          vec3 pixelColor = new vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world, maxDepth));
          }
          write_color(writer1, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone - file 1\r");

      // View Requirement:
      // 2
      HittableList world2 = new HittableList();
      world2.add(new Sphere(new vec3(0.0, -103, -1.0), 100.0, material_ground));
      world2.add(new Sphere(new vec3(0.0,  0.7, -1.3),   0.3, material_center));
      world2.add(new Sphere(new vec3(-1.1, 0.5, -1.2),   1.0, material_left));
      world2.add(new Sphere(new vec3( 1.1, 0.2, -1.1),   0.6, material_right));
      lookfrom = new vec3(3,3,2);
      cam= new Camera(lookfrom, lookat, vup, 20.0, aspectRatio, aperture, distToFocus);
      // write file 2
      writer2.write("P3\n" + width + " " + height + "\n255\n");
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " for file 2");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          vec3 pixelColor = new vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world2, maxDepth));
          }
          write_color(writer2, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone - file 2\r");

      // 3
      HittableList world3 = new HittableList();
      world3.add(new Sphere(new vec3(0.0, -103, -1.0), 100.0, material_ground));
      world3.add(new Sphere(new vec3(0.0,  0.8, -1.3),   0.3, material_center));
      world3.add(new Sphere(new vec3(-1.1, 0.6, -1.2),   1.0, material_left));
      world3.add(new Sphere(new vec3( 1.1, 0.3, -1.1),   0.6, material_right));
      lookfrom = new vec3(4,4,2);
      cam= new Camera(lookfrom, lookat, vup, 20.0, aspectRatio, aperture, distToFocus);
      // write file 3
      writer3.write("P3\n" + width + " " + height + "\n255\n");
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " for file 3");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          vec3 pixelColor = new vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world3, maxDepth));
          }
          write_color(writer3, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone - file 3\r");

      // 4
      HittableList world4 = new HittableList();
      world4.add(new Sphere(new vec3(0.0, -103, -1.0), 100.0, material_ground));
      world4.add(new Sphere(new vec3(0.0,  0.9, -1.3),   0.3, material_center));
      world4.add(new Sphere(new vec3(-1.1, 0.7, -1.2),   1.0, material_left));
      world4.add(new Sphere(new vec3( 1.1, 0.4, -1.1),   0.6, material_right));
      lookfrom = new vec3(5,4,3);
      cam= new Camera(lookfrom, lookat, vup, 20.0, aspectRatio, aperture, distToFocus);
      // write file 4
      writer4.write("P3\n" + width + " " + height + "\n255\n");
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " for file 4");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          vec3 pixelColor = new vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world4, maxDepth));
          }
          write_color(writer4, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone - file 4\r");

      // 5
      HittableList world5 = new HittableList();
      world5.add(new Sphere(new vec3(0.0, -103, -1.0), 100.0, material_ground));
      world5.add(new Sphere(new vec3(0.1,  1.0, -1.3),   0.3, material_center));
      world5.add(new Sphere(new vec3(-1.0, 0.8, -1.2),   1.0, material_left));
      world5.add(new Sphere(new vec3( 1.0, 0.5, -1.1),   0.6, material_right));
      lookfrom = new vec3(6,5,5);
      cam= new Camera(lookfrom, lookat, vup, 20.0, aspectRatio, aperture, distToFocus);
      // write file 5
      writer5.write("P3\n" + width + " " + height + "\n255\n");
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " for file 5");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          vec3 pixelColor = new vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world5, maxDepth));
          }
          write_color(writer5, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone - file 5\r");
    } catch (IOException e) {
      e.printStackTrace();
    }
    // try closing file
    finally {
      try {
        if (writer1 != null)
          writer1.close( );
        if (writer2 != null)
          writer2.close( );
        if (writer3 != null)
          writer3.close( );
        if (writer4 != null)
          writer4.close( );
        if (writer5 != null)
          writer5.close( );
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
