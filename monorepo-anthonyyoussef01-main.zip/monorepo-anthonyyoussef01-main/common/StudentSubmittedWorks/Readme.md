

Some student submitted works (From Assignment 3). Some of the works that students have wanted to share.

- Husky.obj by Anish Satalkar
