## Textures

Provided is a sample PPM image that we could later use as a 'texture' in our graphics programs.

You can find more sample .ppm files in the ./objects directory in several sub-folders with objects.
