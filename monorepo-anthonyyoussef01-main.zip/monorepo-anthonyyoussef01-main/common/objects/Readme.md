Here are some sample .obj files you need to be able to render.

You might consider downloading other files from the web.
