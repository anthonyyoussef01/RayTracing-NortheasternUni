Note in the .mtl there is no .ppm found! In this case, you can simply specify a default texture.
