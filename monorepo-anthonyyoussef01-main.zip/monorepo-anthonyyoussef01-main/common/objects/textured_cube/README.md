A simple textured cube.

Note: Depending on the tool used, the 'front' of the cube may not actually be the front.
