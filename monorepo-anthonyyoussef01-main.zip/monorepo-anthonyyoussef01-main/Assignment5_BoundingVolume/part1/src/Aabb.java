public class Aabb {
  private Vec3 minimum, maximum;

  public Aabb() {  }
  public Aabb(Vec3 a, Vec3 b) {
    minimum = a;
    maximum = b;
  }

  Vec3 min() {
    return minimum;
  }
  Vec3 max() {
    return maximum;
  }

  boolean hit(Ray r, double tMin, double tMax) {
    for (int a = 0; a < 3; a++) {
      var invD = 1.0f / r.getDirection().get(a);
      var t0 = (this.min().get(a) - r.getOrigin().get(a)) * invD;
      var t1 = (this.max().get(a) - r.getOrigin().get(a)) * invD;
      if (invD < 0.0f) {
        var temp = t0;
        t0 = t1;
        t1 = temp;
      }
      tMin = t0 > tMin ? t0 : tMin;
      tMax = t1 < tMax ? t1 : tMax;
      if (tMax <= tMin)
        return false;
    }
    return true;
  }

  // Bounding Volume requirement:
  public static Aabb surroundingBox(Aabb box0, Aabb box1) {
    Vec3 small = new Vec3(
        Math.min(box0.min().x(), box1.min().x()),
        Math.min(box0.min().y(), box1.min().y()),
        Math.min(box0.min().z(), box1.min().z()));

    Vec3 big = new Vec3(
        Math.max(box0.max().x(), box1.max().x()),
        Math.max(box0.max().y(), box1.max().y()),
        Math.max(box0.max().z(), box1.max().z()));

    return new Aabb(small, big);
  }

};