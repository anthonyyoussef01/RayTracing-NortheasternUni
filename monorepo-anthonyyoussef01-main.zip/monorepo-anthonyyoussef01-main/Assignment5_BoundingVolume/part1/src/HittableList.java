import java.util.ArrayList;
import java.util.List;

public class HittableList extends Hittable {
  private List<Hittable> hittableList;
  public int volumeIntersectCounter = 0;
  public int objectIntersectCounter = 0;

  // constructors
  HittableList() {
    this.hittableList = new ArrayList<>();
  }
  HittableList(List<Hittable> hittableList) {
    this.hittableList = hittableList;
  }
  HittableList(Hittable hittableObj) {
    this.hittableList = new ArrayList<>();
    this.hittableList.add(hittableObj);
  }

  public void clear() {
    this.hittableList.clear();
  }

  public void add(Hittable obj) {
      this.hittableList.add(obj);
  }

  @Override
  public boolean hit(Ray ray, double tMin, double tMax, HitRecord hitRecord) {
    HitRecord tempHitRecord = new HitRecord();
    boolean hitAnything = false;
    var closestSoFar = tMax;

    for (Hittable hitbl : hittableList)
      if (hitbl.hit(ray, tMin, closestSoFar, tempHitRecord)) {
        objectIntersectCounter++;
        hitAnything = true;
        closestSoFar = tempHitRecord.getT();
        hitRecord.set(tempHitRecord);
      }
    return hitAnything;
  }

  @Override
  public boolean boundingBox(double time0, double time1, Aabb outputBox) {
    if (hittableList.isEmpty())
      return false;

    Aabb tempBox = new Aabb();
    boolean firstBox = true;

    for (var object : hittableList) {
      if (!object.boundingBox(time0, time1, tempBox))
        return false;
      volumeIntersectCounter++;
      if (firstBox)
        outputBox = tempBox;
      else
        outputBox = Aabb.surroundingBox(outputBox, tempBox);
      firstBox = false;
    }

    return true;
  }
}