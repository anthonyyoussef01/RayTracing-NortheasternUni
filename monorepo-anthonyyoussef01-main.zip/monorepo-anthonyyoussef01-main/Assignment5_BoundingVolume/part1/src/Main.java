import static java.lang.Math.sqrt;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class Main {
  public static double clamp(double x, double min, double max) {
    if (x < min)
      return min;
    if (x > max)
      return max;
    return x;
  }

  public static void write_color(Writer out, Vec3 pixel_color, int samplesPerPixel)
      throws IOException {
    var r = pixel_color.x();
    var g = pixel_color.y();
    var b = pixel_color.z();

    // Divide the color by the number of samples
    // and gamma-correct for gamma=2.0.
    var scale = 1.0 / samplesPerPixel;
    r = sqrt(scale * r);
    g = sqrt(scale * g);
    b = sqrt(scale * b);

    // Write the translated [0,255] value of each color component.
    out.append(
        (int)(256 * clamp(r, 0.0, 0.999)) + " " +
        (int)(256 * clamp(g, 0.0, 0.999)) + " " +
        (int)(256 * clamp(b, 0.0, 0.999)) + "\n");
  }

  public static Vec3 ray_color(Ray r, Hittable world, int depth) {
    HitRecord rec = new HitRecord();

    // ray bounce limit exceeded -> no more light is gathered
    if (depth <= 0)
      return new Vec3(0, 0, 0);

    if (world.hit(r, 0.001, Double.POSITIVE_INFINITY, rec)) {
      Ray scattered = new Ray();
      Vec3 attenuation = new Vec3();
      if (rec.getMat().scatter(r, rec, attenuation, scattered))
        return attenuation.mul(ray_color(scattered, world, depth-1));
      return new Vec3(0, 0, 0);
    }

    Vec3 unit_direction = Vec3.unit_vector(r.getDirection());
    var t = 0.5f * (float)(unit_direction.y() + 1.0);
    /*
    return new Vec3(
        (1.0f - t) * 1.0f + t * 0.5f,
        (1.0f - t) * 1.0f + t * 0.7f,
        (1.0f - t) * 1.0f + t * 1.0f
    );
    */
    return (new Vec3(1.0, 1.0, 1.0).mul(1.0f - t)).add(new Vec3(0.5, 0.7, 1.0).mul(t));
  }

  // returns the degrees value entered in radians
  public static double degrees_to_radians(double degrees) {
    return degrees * Math.PI / 180.0;
  }

  public static double random_double() {
    // The Java Math library function Math.random() generates a double value in the range [0,1)
    return Math.random();
  }

  public static double random_double(double min, double max) {
    // Returns a random real in [min,max)
    var range = max - min + 1;
    return (Math.random() * range) + min;
  }

  public static void main(String[] args) {
    // try opening file first and print stack trace if error encountered
    BufferedWriter writer1 = null;
    try
    {
      writer1 =
          new BufferedWriter(
              new FileWriter(
                  "Assignment5_BoundingVolume/part1/src/output1.ppm"
              )
          );
      // initialize width and height of the canvas
      var aspectRatio = 16.0 / 9.0;
      int width = 400;
      int height = (int)(width / aspectRatio);
      int samplesPerPixel = 100;
      int maxDepth = 50;

      // initialize the world
      HittableList world = new HittableList();
      var material_ground = new Lambertian(new Vec3(0.1, 0.5, 1.0));
      var material_center = new Lambertian(new Vec3(0.5, 0.2, 0.6));
      var material_left   = new Metal(new Vec3(0.1, 0.1, 0.1));
      var material_right  = new Metal(new Vec3(0.7, 1.0, 0.9));
      world.add(
          new MovingSphere(
              new Vec3(0.0, -100.5, -1.0),
              new Vec3(0.0, -101, -1.0),
              0.0, 1.0,100.0, material_ground));
      world.add(new Sphere(new Vec3(0.0,    0.2, -1.3),   0.3, material_center));
      world.add(new Sphere(new Vec3(-1.1,   0.2, -1.2),   1.0, material_left));
      world.add(new Sphere(new Vec3( 1.1,   0.1, -1.1),   0.6, material_right));

      // create a Camera instance
      Vec3 lookfrom = new Vec3(2,3,2);
      Vec3 lookat = new Vec3(0,0,-1);
      Vec3 vup = new Vec3(0,1,0);
      var distToFocus = (lookfrom.sub(lookat)).length();
      var aperture = 2.0;

      Camera cam = new Camera(lookfrom, lookat, vup, 20.0, aspectRatio, aperture, distToFocus, 0.0, 0);

      int raysCast;

      // write file 1
      writer1.write("P3\n" + width + " " + height + "\n255\n");
      raysCast = 0;
      for (int i = height-1; i >= 0; i--) {
        System.out.println("\rScanlines remaining: " + i + " for file 1");
        //System.out.flush();   -- System.out is by default line-buffered
        for (int j = 0; j < width; j++) {
          Vec3 pixelColor = new Vec3(0,0,0);
          for (int k = 0; k < samplesPerPixel; k++) {
            var u = ((double) j + random_double()) / (width-1);
            var v = ((double) i + random_double()) / (height-1);
            Ray r = cam.get_ray(u, v);
            pixelColor = pixelColor.add(ray_color(r, world, maxDepth));
            raysCast += 1;
          }
          write_color(writer1, pixelColor, samplesPerPixel);
        }
      }
      System.out.println("\rDone - file 1\r");
      // Output intersections Requirement:
      System.out.println(
          "Rays Cast: " + raysCast
              + "\nBounding Volume Intersections: " + world.volumeIntersectCounter
              + "\nSuccessful Object Intersections: " + world.objectIntersectCounter + "\r");
    } catch (IOException e) {
      e.printStackTrace();
    }
    // try closing file
    finally {
      try {
        if (writer1 != null)
          writer1.close( );
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
