// abstract class that defines any hittable object
public abstract class Hittable {
  public abstract boolean hit(Ray r, double t_min, double t_max, HitRecord rec);
  public abstract boolean boundingBox(double time0, double time1, Aabb outputBox);
  /*
  public boolean bounding_box(double t0, double t1, AABB box){
    return false;
  }
  public double pdf_value(vec3 o, vec3 v){
    return 0;
  }
  public vec3 random(vec3 o){
    return new vec3(1,0,0);
  }
  */
}

