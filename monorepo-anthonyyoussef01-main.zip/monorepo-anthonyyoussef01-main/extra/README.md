For the most part, you can ignore this directory.

From time to time I may add some snippets here that may be interesting to read.
